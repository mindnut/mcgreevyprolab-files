I have discovered a truly marvelous proof that it is impossible to 
separate a sandwich into two cubes, or four sandwiches into two
fourth of a sandwich, or in general, any sandwich larger than the 
second into two like sandwiches. This text file is too narrow to contain it.
